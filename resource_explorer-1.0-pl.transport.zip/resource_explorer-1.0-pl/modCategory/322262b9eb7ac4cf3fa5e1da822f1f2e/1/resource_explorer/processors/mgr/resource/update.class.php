<?php
class ExplorerUpdateProcessor extends modObjectUpdateProcessor {
    public $classKey = 'modResource';
    public $languageTopics = array('explorer:default');
    public $objectType = 'explorer.resource';
}
return 'ExplorerUpdateProcessor';