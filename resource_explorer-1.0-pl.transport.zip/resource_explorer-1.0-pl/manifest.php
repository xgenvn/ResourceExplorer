<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'Copyright (c) 2013, XGENVN
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met: 

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer. 
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution. 

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are those
of the authors and should not be interpreted as representing official policies, 
either expressed or implied, of the FreeBSD Project.',
    'readme' => '***FOR USERS***
Resource Explorer is a little component to help you achieve following purposes:
- Browsing your blog by parent-child like structure
- Can be used to replace the resource menu, only for content, not Template/Snippet/Chunk/TV management.


***FOR DEVELOPERS***
Resource Explorer can be used as an example of custom manager page. You can add other sections to fit your needs.
The repository is on http://github.com/xgenvn/ResourceExplorer
To use this component under your modx setup for further development:
- In ./config.core.php file, change MODX_CORE_PATH to your setup path

- Create two options under System Settings: dev_path and dev_url, point them to where ResourceExplorer is located at.
----Example: dev_path = {base_path}/x_components/
             dev_url  = {base_url}/x_components/

- Create necessary namespace: resource_explorer
----core_path: {base_path}/x_components/ResourceExplorer/core/components/resource_explorer/
----assets_path: {base_path}/x_components/ResourceExplorer/assets/components/resource_explorer/
I assumed that {base_url}/x_components/ can be accessed through your local web server.

- Create necessary controller and menu item.
----Go to Systems>Actions: Add \'index\' action under Actions>resource_explorer
----Place an Action under Components Menu. The controller has to be \'resource_explorer - index\'

- Now you can make your own changes. Run _build/build.transport.php on your browser to package things up.
The zip file will be located at {base_path}/core/packages/.


About commercial consult and feature-more request, feel free to contact xgenvn@gmail.com',
    'changelog' => '***INITIAL PUBLIC VERSION***
',
    'setup-options' => 'resource_explorer-1.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '7bb60b8fae47b33a2cbe6cb01d7d8efa',
      'native_key' => 'resource_explorer',
      'filename' => 'modNamespace/9692985ece723d5dfbd05f1af8a5acbe.vehicle',
      'namespace' => 'resource_explorer',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a97b5f836263e113e20475c5de87a63c',
      'native_key' => 1,
      'filename' => 'modCategory/322262b9eb7ac4cf3fa5e1da822f1f2e.vehicle',
      'namespace' => 'resource_explorer',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e8b8edf699ead53da0d8d300fe5072d3',
      'native_key' => 'Resource Explorer',
      'filename' => 'modMenu/b91eeaf8f87572e88c133910648e668b.vehicle',
      'namespace' => 'resource_explorer',
    ),
  ),
);